python annotation_pre.py Daeje_Gene04728-AT1G63910.co_MR_gene Calsi
