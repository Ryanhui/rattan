#!perl
#按顺序输入gene.query 和table文件，得到用于网页绘制点阵的数据
open IN,"$ARGV[0]";
open IN1,"$ARGV[1]";
while(<IN>){
	chomp;
	$hash{$_}="";
}
while(<IN1>){
	s/^.*?://;
	@information=split /\t/,$_;
	#print $_,"\n";
	$list.="\t$information[0]";
	foreach $arr(keys %hash){
		
		if(/$arr/){
			$hash{$arr}.="\t$information[0]";
			#print $arr,"\n";
		}
	}
}
$list=~s/^\t//;
	print "$list\n";
foreach $arr1(keys %hash){
	#print $arr1,"\n";
	print "$arr1\t$hash{$arr1}\n";
}
